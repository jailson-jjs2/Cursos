# Repositório de aulas ao vivo para estudantes da Turma 31 😎

Este repositório armazena os códigos e scripts fornecidos durante as aulas ao vivo pelas pessoas especialistas da Trybe.

## Começando

Basta clonar o repositório.

```sh
git clone git@github.com:tryber/sd-031-live-lecture.git
```
---

### Estrutura

Todos os conteúdos dados em aulas estarão no seu respectivo Pull Request! Aproveite esses conteúdos para estudar 😉

---
